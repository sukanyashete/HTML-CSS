<?php
$sname = $_POST['sname'];
$address = $_POST['address'];
$age = $_POST['age'];
$email = $_POST['email'];
$contact = $_POST['contact'];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "itlab";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ( !mysqli_select_db( $conn, $dbname ) ) {
	die( "Could not open database" );
}

$INSERT = "INSERT INTO students (name, address, age, email, contact ) VALUES('" . $sname . "','".$address."',".$age.",'".$email."',".$contact.")";



	if (mysqli_query( $conn, $INSERT)== FALSE){
		echo "Error".$INSERT."<br>" . mysqli_error($conn);
	}
	else{
		
				echo "<br>NEW RECORD INSERTED SUCCESSFULLY..<br><br>";
				$DISPLAY = "SELECT * from students";
				$result = mysqli_query( $conn, $DISPLAY);
				echo "<table border='1'><th>NAME</th><th>ADDRESS</th><th>AGE</th><th>EMAIL</th><th>CONTACT</th>";
				while ($row = mysqli_fetch_row($result)){
				echo "<tr><td>".$row[0]."</td><td>". $row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td></tr>";
				}
				echo "</table>";
	}

	mysqli_close($conn);

?>
	
		